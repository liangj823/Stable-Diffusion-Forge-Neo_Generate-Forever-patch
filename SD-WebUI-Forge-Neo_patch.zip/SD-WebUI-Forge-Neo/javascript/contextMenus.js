let contextMenuInit = function () {
    let eventListenerApplied = false;
    let menuSpecs = new Map();

    const uid = function () {
        return Date.now().toString(36) + Math.random().toString(36).substring(2);
    };

    function showContextMenu(event, element, menuEntries) {
        let oldMenu = gradioApp().querySelector("#context-menu");
        if (oldMenu) {
            oldMenu.remove();
        }

        let baseStyle = window.getComputedStyle(uiCurrentTab);

        const contextMenu = document.createElement("nav");
        contextMenu.id = "context-menu";
        contextMenu.style.background = baseStyle.background;
        contextMenu.style.color = baseStyle.color;
        contextMenu.style.fontFamily = baseStyle.fontFamily;
        contextMenu.style.top = event.pageY + "px";
        contextMenu.style.left = event.pageX + "px";

        const contextMenuList = document.createElement("ul");
        contextMenuList.className = "context-menu-items";
        contextMenu.append(contextMenuList);

        menuEntries.forEach(function (entry) {
            let contextMenuEntry = document.createElement("button");
            contextMenuEntry.type = "button";
            contextMenuEntry.innerHTML = entry["name"];
            contextMenuEntry.addEventListener("click", async function (clickEvent) {
                clickEvent.preventDefault();
                clickEvent.stopPropagation();
                if (typeof clickEvent.stopImmediatePropagation === "function") {
                    clickEvent.stopImmediatePropagation();
                }

                contextMenu.remove();
                await entry["func"]();
            });
            contextMenuList.append(contextMenuEntry);
        });

        gradioApp().appendChild(contextMenu);
    }

    function appendContextMenuOption(
        targetElementSelector,
        entryName,
        entryFunction,
    ) {
        let currentItems = menuSpecs.get(targetElementSelector);

        if (!currentItems) {
            currentItems = [];
            menuSpecs.set(targetElementSelector, currentItems);
        }
        let newItem = {
            id: targetElementSelector + "_" + uid(),
            name: entryName,
            func: entryFunction,
            isNew: true,
        };

        currentItems.push(newItem);
        return newItem["id"];
    }

    function removeContextMenuOption(uid) {
        menuSpecs.forEach(function (v) {
            let index = -1;
            v.forEach(function (e, ei) {
                if (e["id"] == uid) {
                    index = ei;
                }
            });
            if (index >= 0) {
                v.splice(index, 1);
            }
        });
    }

    function addContextMenuEventListener() {
        if (eventListenerApplied) {
            return;
        }
        gradioApp().addEventListener("click", function (e) {
            if (!e.isTrusted) {
                return;
            }

            let oldMenu = gradioApp().querySelector("#context-menu");
            if (oldMenu) {
                oldMenu.remove();
            }
        });
        ["contextmenu", "touchstart"].forEach((eventType) => {
            gradioApp().addEventListener(eventType, function (e) {
                let ev = e;
                if (eventType.startsWith("touch")) {
                    if (e.touches.length !== 2) return;
                    ev = e.touches[0];
                }
                let oldMenu = gradioApp().querySelector("#context-menu");
                if (oldMenu) {
                    oldMenu.remove();
                }
                menuSpecs.forEach(function (v, k) {
                    if (e.composedPath()[0].matches(k)) {
                        showContextMenu(ev, e.composedPath()[0], v);
                        e.preventDefault();
                    }
                });
            });
        });
        eventListenerApplied = true;
    }

    return [
        appendContextMenuOption,
        removeContextMenuOption,
        addContextMenuEventListener,
    ];
};

let initResponse = contextMenuInit();
let appendContextMenuOption = initResponse[0];
let removeContextMenuOption = initResponse[1];
let addContextMenuEventListener = initResponse[2];

let regen_txt2img = false;
let regen_img2img = false;

(function () {
    //Start example Context Menu Items
    let isInterruptIdle = function (interrupt) {
        if (!interrupt) {
            return false;
        }

        return !interrupt.offsetParent || window.getComputedStyle(interrupt).display == "none";
    };

    let setGenerateForever = function (tabname, enabled) {
        return fetch("./internal/generate-forever", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ tabname: tabname, enabled: enabled }),
        }).catch(function (error) {
            console.error("Failed to toggle generate forever", error);
        });
    };

    let generateOnRepeat_txt2img = async function () {
        let generate = gradioApp().querySelector("#txt2img_generate");
        let interrupt = gradioApp().querySelector("#txt2img_interrupt");
        regen_txt2img = true;
        regen_img2img = false;
        await setGenerateForever("txt2img", true);
        if (isInterruptIdle(interrupt)) {
            setTimeout(function () {
                generate.click();
            }, 0);
        }
    };
    appendContextMenuOption(
        "#txt2img_generate",
        "Generate forever",
        generateOnRepeat_txt2img,
    );
    appendContextMenuOption(
        "#txt2img_interrupt",
        "Generate forever",
        generateOnRepeat_txt2img,
    );

    let cancel_regen_txt2img = async function () {
        await setGenerateForever("txt2img", false);
        regen_txt2img = false;
        regen_img2img = false;
    };
    appendContextMenuOption(
        "#txt2img_interrupt",
        "Cancel generate forever",
        cancel_regen_txt2img,
    );
    appendContextMenuOption(
        "#txt2img_generate",
        "Cancel generate forever",
        cancel_regen_txt2img,
    );

    let generateOnRepeat_img2img = async function () {
        let generate = gradioApp().querySelector("#img2img_generate");
        let interrupt = gradioApp().querySelector("#img2img_interrupt");
        regen_txt2img = false;
        regen_img2img = true;
        await setGenerateForever("img2img", true);
        if (isInterruptIdle(interrupt)) {
            setTimeout(function () {
                generate.click();
            }, 0);
        }
    };
    appendContextMenuOption(
        "#img2img_generate",
        "Generate forever",
        generateOnRepeat_img2img,
    );
    appendContextMenuOption(
        "#img2img_interrupt",
        "Generate forever",
        generateOnRepeat_img2img,
    );

    let cancel_regen_img2img = async function () {
        await setGenerateForever("img2img", false);
        regen_txt2img = false;
        regen_img2img = false;
    };
    appendContextMenuOption(
        "#img2img_interrupt",
        "Cancel generate forever",
        cancel_regen_img2img,
    );
    appendContextMenuOption(
        "#img2img_generate",
        "Cancel generate forever",
        cancel_regen_img2img,
    );
})();

onAfterUiUpdate(addContextMenuEventListener);
